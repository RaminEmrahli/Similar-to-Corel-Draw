﻿namespace CorelDraw
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panelMain = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.toolStrip4 = new System.Windows.Forms.ToolStrip();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBoxNoFill = new System.Windows.Forms.CheckBox();
            this.pictureBoxNoFill = new System.Windows.Forms.PictureBox();
            this.pictureBoxFill = new System.Windows.Forms.PictureBox();
            this.checkBoxFill = new System.Windows.Forms.CheckBox();
            this.panelChangeableColors = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.btnBorderColor = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btnFillColor = new System.Windows.Forms.Button();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.comboBoxWidth = new System.Windows.Forms.ComboBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.pictureBoxHeight = new System.Windows.Forms.PictureBox();
            this.pictureBoxWidth = new System.Windows.Forms.PictureBox();
            this.txtLocationY = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLocationX = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tSBtnPen = new System.Windows.Forms.ToolStripButton();
            this.tsBtnEraser = new System.Windows.Forms.ToolStripButton();
            this.tSBtnCursor = new System.Windows.Forms.ToolStripButton();
            this.tSBtnRectangle = new System.Windows.Forms.ToolStripButton();
            this.tSBtnEllipse = new System.Windows.Forms.ToolStripButton();
            this.toolStripColors = new System.Windows.Forms.ToolStrip();
            this.tsButtonColor = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton19 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton18 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton24 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton21 = new System.Windows.Forms.ToolStripButton();
            this.tsButtonPalette = new System.Windows.Forms.ToolStripButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelMain.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNoFill)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFill)).BeginInit();
            this.panelChangeableColors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWidth)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.toolStripColors.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMain
            // 
            this.panelMain.Controls.Add(this.button1);
            this.panelMain.Controls.Add(this.toolStrip4);
            this.panelMain.Controls.Add(this.panel1);
            this.panelMain.Controls.Add(this.panelChangeableColors);
            this.panelMain.Controls.Add(this.toolStrip3);
            this.panelMain.Controls.Add(this.pictureBox2);
            this.panelMain.Controls.Add(this.comboBoxWidth);
            this.panelMain.Controls.Add(this.txtHeight);
            this.panelMain.Controls.Add(this.toolStrip2);
            this.panelMain.Controls.Add(this.txtWidth);
            this.panelMain.Controls.Add(this.pictureBoxHeight);
            this.panelMain.Controls.Add(this.pictureBoxWidth);
            this.panelMain.Controls.Add(this.txtLocationY);
            this.panelMain.Controls.Add(this.label2);
            this.panelMain.Controls.Add(this.txtLocationX);
            this.panelMain.Controls.Add(this.label1);
            resources.ApplyResources(this.panelMain, "panelMain");
            this.panelMain.Name = "panelMain";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // toolStrip4
            // 
            resources.ApplyResources(this.toolStrip4, "toolStrip4");
            this.toolStrip4.Name = "toolStrip4";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBoxNoFill);
            this.panel1.Controls.Add(this.pictureBoxNoFill);
            this.panel1.Controls.Add(this.pictureBoxFill);
            this.panel1.Controls.Add(this.checkBoxFill);
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // checkBoxNoFill
            // 
            resources.ApplyResources(this.checkBoxNoFill, "checkBoxNoFill");
            this.checkBoxNoFill.Checked = true;
            this.checkBoxNoFill.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxNoFill.Name = "checkBoxNoFill";
            this.checkBoxNoFill.UseVisualStyleBackColor = true;
            this.checkBoxNoFill.Click += new System.EventHandler(this.checkBoxNoFill_Click);
            // 
            // pictureBoxNoFill
            // 
            resources.ApplyResources(this.pictureBoxNoFill, "pictureBoxNoFill");
            this.pictureBoxNoFill.Name = "pictureBoxNoFill";
            this.pictureBoxNoFill.TabStop = false;
            this.pictureBoxNoFill.Click += new System.EventHandler(this.pictureBoxNoFill_Click);
            // 
            // pictureBoxFill
            // 
            resources.ApplyResources(this.pictureBoxFill, "pictureBoxFill");
            this.pictureBoxFill.Name = "pictureBoxFill";
            this.pictureBoxFill.TabStop = false;
            this.pictureBoxFill.Click += new System.EventHandler(this.pictureBoxFill_Click);
            // 
            // checkBoxFill
            // 
            resources.ApplyResources(this.checkBoxFill, "checkBoxFill");
            this.checkBoxFill.Name = "checkBoxFill";
            this.checkBoxFill.UseVisualStyleBackColor = true;
            this.checkBoxFill.Click += new System.EventHandler(this.checkBoxFill_Click);
            // 
            // panelChangeableColors
            // 
            this.panelChangeableColors.Controls.Add(this.label4);
            this.panelChangeableColors.Controls.Add(this.btnBorderColor);
            this.panelChangeableColors.Controls.Add(this.label3);
            this.panelChangeableColors.Controls.Add(this.btnFillColor);
            resources.ApplyResources(this.panelChangeableColors, "panelChangeableColors");
            this.panelChangeableColors.Name = "panelChangeableColors";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // btnBorderColor
            // 
            this.btnBorderColor.BackColor = System.Drawing.Color.Black;
            resources.ApplyResources(this.btnBorderColor, "btnBorderColor");
            this.btnBorderColor.Name = "btnBorderColor";
            this.btnBorderColor.UseVisualStyleBackColor = false;
            this.btnBorderColor.Click += new System.EventHandler(this.btnBorderColor_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // btnFillColor
            // 
            this.btnFillColor.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.btnFillColor, "btnFillColor");
            this.btnFillColor.Name = "btnFillColor";
            this.btnFillColor.UseVisualStyleBackColor = false;
            this.btnFillColor.Click += new System.EventHandler(this.btnFillColor_Click);
            // 
            // toolStrip3
            // 
            resources.ApplyResources(this.toolStrip3, "toolStrip3");
            this.toolStrip3.Name = "toolStrip3";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // comboBoxWidth
            // 
            resources.ApplyResources(this.comboBoxWidth, "comboBoxWidth");
            this.comboBoxWidth.FormattingEnabled = true;
            this.comboBoxWidth.Items.AddRange(new object[] {
            resources.GetString("comboBoxWidth.Items"),
            resources.GetString("comboBoxWidth.Items1"),
            resources.GetString("comboBoxWidth.Items2"),
            resources.GetString("comboBoxWidth.Items3"),
            resources.GetString("comboBoxWidth.Items4"),
            resources.GetString("comboBoxWidth.Items5"),
            resources.GetString("comboBoxWidth.Items6"),
            resources.GetString("comboBoxWidth.Items7"),
            resources.GetString("comboBoxWidth.Items8"),
            resources.GetString("comboBoxWidth.Items9")});
            this.comboBoxWidth.Name = "comboBoxWidth";
            this.comboBoxWidth.SelectedIndexChanged += new System.EventHandler(this.comboBoxWidth_SelectedIndexChanged);
            // 
            // txtHeight
            // 
            resources.ApplyResources(this.txtHeight, "txtHeight");
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.TextChanged += new System.EventHandler(this.txtHeight_TextChanged);
            this.txtHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLocationX_KeyPress);
            // 
            // toolStrip2
            // 
            resources.ApplyResources(this.toolStrip2, "toolStrip2");
            this.toolStrip2.Name = "toolStrip2";
            // 
            // txtWidth
            // 
            resources.ApplyResources(this.txtWidth, "txtWidth");
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.TextChanged += new System.EventHandler(this.txtWidth_TextChanged);
            this.txtWidth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLocationX_KeyPress);
            // 
            // pictureBoxHeight
            // 
            resources.ApplyResources(this.pictureBoxHeight, "pictureBoxHeight");
            this.pictureBoxHeight.Name = "pictureBoxHeight";
            this.pictureBoxHeight.TabStop = false;
            // 
            // pictureBoxWidth
            // 
            resources.ApplyResources(this.pictureBoxWidth, "pictureBoxWidth");
            this.pictureBoxWidth.Name = "pictureBoxWidth";
            this.pictureBoxWidth.TabStop = false;
            // 
            // txtLocationY
            // 
            resources.ApplyResources(this.txtLocationY, "txtLocationY");
            this.txtLocationY.Name = "txtLocationY";
            this.txtLocationY.TextChanged += new System.EventHandler(this.txtLocationX_TextChanged);
            this.txtLocationY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLocationX_KeyPress);
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // txtLocationX
            // 
            resources.ApplyResources(this.txtLocationX, "txtLocationX");
            this.txtLocationX.Name = "txtLocationX";
            this.txtLocationX.TextChanged += new System.EventHandler(this.txtLocationX_TextChanged);
            this.txtLocationX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLocationX_KeyPress);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // toolStrip1
            // 
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tSBtnPen,
            this.tsBtnEraser,
            this.tSBtnCursor,
            this.tSBtnRectangle,
            this.tSBtnEllipse});
            this.toolStrip1.Name = "toolStrip1";
            // 
            // tSBtnPen
            // 
            this.tSBtnPen.Checked = true;
            this.tSBtnPen.CheckOnClick = true;
            this.tSBtnPen.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tSBtnPen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.tSBtnPen, "tSBtnPen");
            this.tSBtnPen.Name = "tSBtnPen";
            this.tSBtnPen.Click += new System.EventHandler(this.tSBtnPen_Click);
            this.tSBtnPen.MouseEnter += new System.EventHandler(this.tSBtnPen_MouseEnter);
            // 
            // tsBtnEraser
            // 
            this.tsBtnEraser.CheckOnClick = true;
            this.tsBtnEraser.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.tsBtnEraser, "tsBtnEraser");
            this.tsBtnEraser.Name = "tsBtnEraser";
            this.tsBtnEraser.Click += new System.EventHandler(this.tsBtnEraser_Click);
            this.tsBtnEraser.MouseEnter += new System.EventHandler(this.tSBtnPen_MouseEnter);
            // 
            // tSBtnCursor
            // 
            this.tSBtnCursor.CheckOnClick = true;
            this.tSBtnCursor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.tSBtnCursor, "tSBtnCursor");
            this.tSBtnCursor.Name = "tSBtnCursor";
            this.tSBtnCursor.Click += new System.EventHandler(this.tSBtnCursor_Click);
            this.tSBtnCursor.MouseEnter += new System.EventHandler(this.tSBtnPen_MouseEnter);
            // 
            // tSBtnRectangle
            // 
            this.tSBtnRectangle.CheckOnClick = true;
            this.tSBtnRectangle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.tSBtnRectangle, "tSBtnRectangle");
            this.tSBtnRectangle.Name = "tSBtnRectangle";
            this.tSBtnRectangle.Click += new System.EventHandler(this.tSBtnRectangle_Click);
            this.tSBtnRectangle.MouseEnter += new System.EventHandler(this.tSBtnPen_MouseEnter);
            // 
            // tSBtnEllipse
            // 
            this.tSBtnEllipse.CheckOnClick = true;
            this.tSBtnEllipse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.tSBtnEllipse, "tSBtnEllipse");
            this.tSBtnEllipse.Name = "tSBtnEllipse";
            this.tSBtnEllipse.Click += new System.EventHandler(this.tSBtnEllipse_Click);
            this.tSBtnEllipse.MouseEnter += new System.EventHandler(this.tSBtnPen_MouseEnter);
            // 
            // toolStripColors
            // 
            resources.ApplyResources(this.toolStripColors, "toolStripColors");
            this.toolStripColors.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsButtonColor,
            this.toolStripButton8,
            this.toolStripButton7,
            this.toolStripButton6,
            this.toolStripButton5,
            this.toolStripButton4,
            this.toolStripButton3,
            this.toolStripButton2,
            this.toolStripButton1,
            this.toolStripButton13,
            this.toolStripButton12,
            this.toolStripButton11,
            this.toolStripButton10,
            this.toolStripButton19,
            this.toolStripButton18,
            this.toolStripButton17,
            this.toolStripButton16,
            this.toolStripButton24,
            this.toolStripButton23,
            this.toolStripButton22,
            this.toolStripButton21,
            this.tsButtonPalette});
            this.toolStripColors.Name = "toolStripColors";
            this.toolStripColors.MouseEnter += new System.EventHandler(this.toolStripColors_MouseEnter_1);
            // 
            // tsButtonColor
            // 
            resources.ApplyResources(this.tsButtonColor, "tsButtonColor");
            this.tsButtonColor.AutoToolTip = false;
            this.tsButtonColor.BackColor = System.Drawing.Color.Black;
            this.tsButtonColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.tsButtonColor.Name = "tsButtonColor";
            this.tsButtonColor.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton8
            // 
            resources.ApplyResources(this.toolStripButton8, "toolStripButton8");
            this.toolStripButton8.AutoToolTip = false;
            this.toolStripButton8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton7
            // 
            resources.ApplyResources(this.toolStripButton7, "toolStripButton7");
            this.toolStripButton7.AutoToolTip = false;
            this.toolStripButton7.BackColor = System.Drawing.Color.Gray;
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton6
            // 
            resources.ApplyResources(this.toolStripButton6, "toolStripButton6");
            this.toolStripButton6.AutoToolTip = false;
            this.toolStripButton6.BackColor = System.Drawing.Color.Silver;
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton5
            // 
            resources.ApplyResources(this.toolStripButton5, "toolStripButton5");
            this.toolStripButton5.AutoToolTip = false;
            this.toolStripButton5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton4
            // 
            resources.ApplyResources(this.toolStripButton4, "toolStripButton4");
            this.toolStripButton4.AutoToolTip = false;
            this.toolStripButton4.BackColor = System.Drawing.Color.White;
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton3
            // 
            resources.ApplyResources(this.toolStripButton3, "toolStripButton3");
            this.toolStripButton3.AutoToolTip = false;
            this.toolStripButton3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton2
            // 
            resources.ApplyResources(this.toolStripButton2, "toolStripButton2");
            this.toolStripButton2.AutoToolTip = false;
            this.toolStripButton2.BackColor = System.Drawing.Color.Cyan;
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton1
            // 
            resources.ApplyResources(this.toolStripButton1, "toolStripButton1");
            this.toolStripButton1.AutoToolTip = false;
            this.toolStripButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton13
            // 
            resources.ApplyResources(this.toolStripButton13, "toolStripButton13");
            this.toolStripButton13.AutoToolTip = false;
            this.toolStripButton13.BackColor = System.Drawing.Color.Yellow;
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton12
            // 
            resources.ApplyResources(this.toolStripButton12, "toolStripButton12");
            this.toolStripButton12.AutoToolTip = false;
            this.toolStripButton12.BackColor = System.Drawing.Color.Red;
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton11
            // 
            resources.ApplyResources(this.toolStripButton11, "toolStripButton11");
            this.toolStripButton11.AutoToolTip = false;
            this.toolStripButton11.BackColor = System.Drawing.Color.Fuchsia;
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton10
            // 
            resources.ApplyResources(this.toolStripButton10, "toolStripButton10");
            this.toolStripButton10.AutoToolTip = false;
            this.toolStripButton10.BackColor = System.Drawing.Color.Purple;
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton19
            // 
            resources.ApplyResources(this.toolStripButton19, "toolStripButton19");
            this.toolStripButton19.AutoToolTip = false;
            this.toolStripButton19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.toolStripButton19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton19.Name = "toolStripButton19";
            this.toolStripButton19.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton18
            // 
            resources.ApplyResources(this.toolStripButton18, "toolStripButton18");
            this.toolStripButton18.AutoToolTip = false;
            this.toolStripButton18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.toolStripButton18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton18.Name = "toolStripButton18";
            this.toolStripButton18.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton17
            // 
            resources.ApplyResources(this.toolStripButton17, "toolStripButton17");
            this.toolStripButton17.AutoToolTip = false;
            this.toolStripButton17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.toolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton16
            // 
            resources.ApplyResources(this.toolStripButton16, "toolStripButton16");
            this.toolStripButton16.AutoToolTip = false;
            this.toolStripButton16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton24
            // 
            resources.ApplyResources(this.toolStripButton24, "toolStripButton24");
            this.toolStripButton24.AutoToolTip = false;
            this.toolStripButton24.BackColor = System.Drawing.Color.MediumTurquoise;
            this.toolStripButton24.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton24.Name = "toolStripButton24";
            this.toolStripButton24.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton23
            // 
            resources.ApplyResources(this.toolStripButton23, "toolStripButton23");
            this.toolStripButton23.AutoToolTip = false;
            this.toolStripButton23.BackColor = System.Drawing.Color.MediumOrchid;
            this.toolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton23.Name = "toolStripButton23";
            this.toolStripButton23.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton22
            // 
            resources.ApplyResources(this.toolStripButton22, "toolStripButton22");
            this.toolStripButton22.AutoToolTip = false;
            this.toolStripButton22.BackColor = System.Drawing.Color.SteelBlue;
            this.toolStripButton22.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton22.Name = "toolStripButton22";
            this.toolStripButton22.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // toolStripButton21
            // 
            resources.ApplyResources(this.toolStripButton21, "toolStripButton21");
            this.toolStripButton21.AutoToolTip = false;
            this.toolStripButton21.BackColor = System.Drawing.Color.LightSkyBlue;
            this.toolStripButton21.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
            this.toolStripButton21.Name = "toolStripButton21";
            this.toolStripButton21.Click += new System.EventHandler(this.PickedColor_Click);
            // 
            // tsButtonPalette
            // 
            resources.ApplyResources(this.tsButtonPalette, "tsButtonPalette");
            this.tsButtonPalette.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsButtonPalette.Image = global::CorelDraw.Properties.Resources.icons8_palette_481;
            this.tsButtonPalette.Name = "tsButtonPalette";
            this.tsButtonPalette.Click += new System.EventHandler(this.tsButtonPalette_Click);
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.toolStripColors);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.panelMain);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelMain.ResumeLayout(false);
            this.panelMain.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxNoFill)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFill)).EndInit();
            this.panelChangeableColors.ResumeLayout(false);
            this.panelChangeableColors.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWidth)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.toolStripColors.ResumeLayout(false);
            this.toolStripColors.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMain;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tSBtnCursor;
        private System.Windows.Forms.TextBox txtLocationY;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtLocationX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripButton tSBtnRectangle;
        private System.Windows.Forms.ToolStripButton tSBtnEllipse;
        private System.Windows.Forms.ToolStripButton tSBtnPen;
        private System.Windows.Forms.ToolStripButton tsBtnEraser;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBoxHeight;
        private System.Windows.Forms.PictureBox pictureBoxWidth;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ComboBox comboBoxWidth;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.Panel panelChangeableColors;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnBorderColor;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnFillColor;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBoxFill;
        private System.Windows.Forms.CheckBox checkBoxNoFill;
        private System.Windows.Forms.PictureBox pictureBoxFill;
        private System.Windows.Forms.PictureBox pictureBoxNoFill;
        private System.Windows.Forms.ToolStrip toolStrip4;
        private System.Windows.Forms.ToolStrip toolStripColors;
        private System.Windows.Forms.ToolStripButton tsButtonColor;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripButton toolStripButton19;
        private System.Windows.Forms.ToolStripButton toolStripButton18;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripButton toolStripButton24;
        private System.Windows.Forms.ToolStripButton toolStripButton23;
        private System.Windows.Forms.ToolStripButton toolStripButton22;
        private System.Windows.Forms.ToolStripButton toolStripButton21;
        private System.Windows.Forms.ToolStripButton tsButtonPalette;
        private System.Windows.Forms.Button button1;
    }
}

